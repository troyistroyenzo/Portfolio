package bankPackage;


public class BasicAccount extends Account {

    public BasicAccount(AccountData accountData) {
        super(accountData);
    }
}
