# CashMachine
An example cash machine &lt;-> bank system implementation

## Task Brief

* 2 Accounts: Basic, Premium
* Each account has: id, name, email, balance
* Cash machine: enter account id, then deposit, withdraw, exit