#ifndef HEADER_H
#define HEADER_H
#include "Header.h"
#include <iostream>
#include<conio.h>
#include<dos.h>
#include <windows.h>
#include<time.h>

#define SCREEN_WIDTH 90
#define SCREEN_HEIGHT 26
#define WIN_WIDTH 70
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

int carPos = WIN_WIDTH/2;
int score = 0;

int enemyY[5];
int enemyX[5];
int enemyFlag[3];


// Gameplay
void gotoxy(int x, int y);
void setcursor(bool visible, DWORD size);
void drawBorder();

// Enemy Stuff
void genEnemy(int ind);
void drawEnemy(int ind);
void eraseEnemy(int ind);
void resetEnemy(int ind);
int collision();
void gameover();
void updateScore();
void instructions();


// Car
void drawCar();
void eraseCar();


// Play
void play();




#endif
