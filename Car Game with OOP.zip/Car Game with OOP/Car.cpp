#include "Header.h"
#include <iostream>
#include<conio.h>
#include<dos.h>
#include <windows.h>
#include<time.h>



using namespace std;
			
char car[4][4]  = {' ', '�', '�', ' ',
				  '�', '*', '*', '�', 
				  ' ', '*', ' *', ' ', 
				  '�', '*', '*', '�',}; 
				  
void drawCar() {
	for(int i = 0; i<4; i++) {
		for(int j = 0; j<4; j++) {
			gotoxy(j+carPos, i+22); cout << car[i][j];
		}
	}
	
}

void eraseCar() {
	for(int i = 0; i<4; i++) {
		for(int j = 0; j<4; j++) {
			gotoxy(j+carPos, i+22); cout << " ";
		}
	}
	
}
