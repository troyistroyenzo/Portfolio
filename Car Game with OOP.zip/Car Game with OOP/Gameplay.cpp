
#include <iostream>
#include<conio.h>
#include<dos.h>
#include <windows.h>
#include<time.h>
#include "Header.h"

using namespace std;


void gotoxy(int x, int y) {
	CursorPosition.X = x;
	CursorPosition.Y = y;
	SetConsoleCursorPosition(console, CursorPosition);
}

void setcursor(bool visible, DWORD size) {
	if(size == 0)
		size = 20;
		
	CONSOLE_CURSOR_INFO lpCursor;
	lpCursor.bVisible = visible;
	lpCursor.dwSize = size;
	SetConsoleCursorInfo (console, &lpCursor);
}

void drawBorder() {
	for(int i = 0; i < SCREEN_HEIGHT; i++) {
		for(int j = 0; j < 17; j++) {
			gotoxy(0+j, i); cout << "�";
			gotoxy(WIN_WIDTH-j, i); cout << "�";
		}
	}
	
	for(int i = 0; i < SCREEN_HEIGHT; i++) {
		gotoxy(SCREEN_WIDTH, i); cout << "�";
	}
		
}

int collision() {
	if((enemyY[0]) + 4 >= 23) {
		if(enemyX[0] + 4 - carPos >= 0 && enemyX[0] + 4 - carPos < 9) {
			return 1;
		}
	}
	return 0;
}

void gameover() {
	system("cls");
	cout << "it's over.";
	getch();
}

void updateScore() {
	
	gotoxy(WIN_WIDTH + 7, 5); cout << "Score: " << score << endl;
	
	
}

void instructions() {
	system("cls");
	cout << "Avoid cars, A = left, d = right, escape = exit" << endl;
	cout << "Press any key to continue";
	getch();
}
