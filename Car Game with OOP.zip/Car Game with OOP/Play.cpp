
#include <iostream>
#include<conio.h>
#include<dos.h>
#include <windows.h>
#include <iostream>
#include<conio.h>
#include<dos.h>
#include <windows.h>
#include<time.h>


#include "Header.h"

using namespace std;


void play() {
	
	carPos = -1 + WIN_WIDTH/2;
	score = 0;
	enemyFlag[0] = 1;
	enemyFlag[1] = 0;
	enemyY[0] = enemyY[1] = 1;
	
	system("cls");
	drawBorder();
	updateScore();
	genEnemy(0);
	genEnemy(1);
	
	gotoxy(WIN_WIDTH + 7, 2); cout << "THE CAR GAME";
	gotoxy(WIN_WIDTH + 6, 4); cout << "---------";
	gotoxy(WIN_WIDTH + 7, 12); cout << "CONTROLS:";
	gotoxy(WIN_WIDTH + 7, 13); cout << "---------";
	gotoxy(WIN_WIDTH + 2, 14); cout << "A Key - Left";
	gotoxy(WIN_WIDTH + 2, 15); cout << "D Key - Right";
	
	gotoxy(18, 5); cout << "Press any key to begin";
	getch();
	gotoxy(18, 5); cout << "                        ";
	
	
	while(1) {
		if(kbhit()) {
			char ch = getch();
			if( ch == 'a' || ch == 'A') {
				// Change speed of left
				if( carPos > 18 )
					carPos -= 4;
			}
			if( ch == 'd' || ch == 'D') {
				// Change speed of right
				if( carPos < 50 )
					carPos += 4;
			}
			if(ch==27) {
				break;
			}
		}
		
		drawCar();
		drawEnemy(0);
		drawEnemy(1);
		if ( collision() == 1) {
			gameover();
			return;
		}
		Sleep(50);
		eraseCar();
		eraseEnemy(0);
		eraseEnemy(1);

		if (enemyY[0] == 10)
			if( enemyFlag[1] == 0 )
		    	enemyFlag[1] = 1;
		    	
			if(enemyFlag[0] == 1)
				enemyY[0] += 1;
				
			if ( enemyFlag[1] == 1)
				enemyY[1] += 1;
				
			if(enemyY[0] > SCREEN_HEIGHT - 4) {
				resetEnemy(0);
				score++;
				updateScore();
			}
			if( enemyY[1] > SCREEN_HEIGHT- 4) {
				resetEnemy(1);
				score++;
				updateScore();
			}
	}
	
}

